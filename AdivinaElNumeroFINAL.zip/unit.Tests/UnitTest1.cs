namespace unit.Tests;

public class UnitTest1
{
    [Fact]
    public void dificultadfacil()
    {
        int resultadoesperado = 1;
        int numero = Program.dificultadfacil();
        Assert.Equal(resultadoesperado, numero);
        
    }
    [Fact]
    public void dificultadmedio()
    {
        int resultadomedio = 2;
        int numeromedio = Program.dificultadmedio();
        Assert.Equal(resultadomedio, numeromedio);
        
    }
    [Fact]
    public void dificultaddificil()
    {
        int resultadodificil = 3;
        int numerodificil = Program.dificultaddificil();
        Assert.Equal(resultadodificil, numerodificil);
        
    }
    [Fact]
    public void dificultadimposible()
    {
        int  resultadoimposible = 4;
        int numeroimposible = Program.dificultadimposible();
        Assert.Equal(resultadoimposible, numeroimposible);

    }
}