#include <iostream>
#include <cstdlib>
#include <ctime>
#include <limits>

using namespace std;

int main() {
    srand(time(0)); // Inicializar la semilla de números aleatorios

    int max_numero, intentos_maximos;

    cout << "Bienvenido al juego de adivina el número!" << endl;
    cout << "Selecciona una dificultad: " << endl;
    cout << "1 - Fácil (números entre 1 y 20, 3 intentos)" << endl;
    cout << "2 - Normal (números entre 1 y 50, 3 intentos)" << endl;
    cout << "3 - Difícil (números entre 1 y 100, 3 intentos)" << endl;
    cout << "4 - IMPOSIBLE (números entre 1 y 500, 3 intentos)" << endl;
    int opcion;
    cin >> opcion;

    switch (opcion) {
        case 1:
            max_numero = 20;
            intentos_maximos = 3;
            break;
        case 2:
            max_numero = 50;
            intentos_maximos = 3;
            break;
        case 3:
            max_numero = 100;
            intentos_maximos = 3;
            break;
        case 4:
            max_numero = 500;
            intentos_maximos = 3;
            break;
        default:
            cout << "Opción inválida. Seleccionando dificultad normal." << endl;
            max_numero = 50;
            intentos_maximos = 7;
            break;
    }

    int numero_secreto = rand() % max_numero + 1; // Generar un número aleatorio dentro del rango establecido
    int intentos = 0;
    int intento_usuario;
    int vidas = 3;

    cout << "Estoy pensando en un número entre 1 y " << max_numero << ". Adivina cuál es." << endl;

    while (vidas > 0 && intentos < intentos_maximos) {
        cout << "Introduce tu intento: ";

        while (!(cin >> intento_usuario)) {
            cout << "Error. Debes ingresar un número válido." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        if (intento_usuario < numero_secreto) {
            cout << "Demasiado bajo." << endl;
        } else if (intento_usuario > numero_secreto) {
            cout << "Demasiado alto." << endl;
        } else {
            cout << "¡Felicidades! Adivinaste el número en " << intentos + 1 << " intentos." << endl;
            return 0;
        }

        intentos++;
        vidas--;
        cout << "Te quedan " << vidas << " vidas." << endl;
    }

    cout << "Lo siento, has perdido. El número era " << numero_secreto << "." << endl;

    return 0;
}