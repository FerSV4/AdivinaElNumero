﻿using System;

namespace unit // Note: actual namespace depends on the project name.
{
    public static class Program
    {
        public static void Main(string[] args)
        {

            Console.WriteLine("Hello World!");
        } 
        public static int dificultadfacil(){
            return 1;
        }
        public static int dificultadmedio(){
            return 2;
        }
        public static int dificultaddificil(){
            return 3;
        }
    }   
}